1) Install Node and NPM
2) open CLI and navigate to the directory react-canvasjs-chart and execulte following commands
3) npm install
3) npm start
4) In browser open http://localhost:8080/index.html